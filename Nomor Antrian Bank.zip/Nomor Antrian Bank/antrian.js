var myVar = setInterval(angka1, 8000);
var myVar = setInterval(angka2, 10000);
var myVar = setInterval(angka3, 15000);
var myVar = setInterval(tampil, 5000);
	function dekerasi()
	{
		angka = 0;
		document.getElementById('antrian1').value = angka;
		document.getElementById('antrian2').value = angka;
		document.getElementById('antrian3').value = angka;
	}

	function angka1()
	{
		var b = document.getElementById('antrian1').value
		var c = parseInt(b);
		var d = document.getElementById('antrian2').value
		var e = parseInt(d);
		var f = document.getElementById('antrian3').value
		var g = parseInt(f);
		
		if(c == 0)
		{
			if(c == 0)
			{
			var hasil = c + 1;
				document.getElementById('antrian1').value = hasil;
                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "1";
			}
			if(e == 1)
			{
			var hasil = e + 1;
				document.getElementById('antrian1').value = hasil;
                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "1";
			}
			if(g == 1)
			{
			var hasil = g + 1;
				document.getElementById('antrian1').value = hasil;
                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "1";
			}
		}
		
		if(c > g & c < e)
		{
			var hasil = e + 1;
			document.getElementById('antrian1').value = hasil;
            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "1";
		}
		
		if(c < g & c > e)
		{
			var hasil = g + 1;
			document.getElementById('antrian1').value = hasil;
            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "1";
		}
		
		if(c < e & c < g & g > e)
		{
			var hasil = g + 1;
			document.getElementById('antrian1').value = hasil;
            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "1";
		}
		
		if(c < e & c < g & e > g)
		{
			var hasil = e + 1;
			document.getElementById('antrian1').value = hasil;
            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "1";
		}
		
		if(c > e & c > g)
		{
			var hasil = c + 1;
			document.getElementById('antrian1').value = hasil;
            document.getElementById('teleer'). innerHTML = "1";
		}
		
		
	}
	function angka2()
	{
		var b = document.getElementById('antrian1').value
		var c = parseInt(b);
		var d = document.getElementById('antrian2').value
		var e = parseInt(d);
		var f = document.getElementById('antrian3').value
		var g = parseInt(f);
		
		if(e == 0)
		{
			if(e == 0)
			{
			var hasil = c + 1;
				document.getElementById('antrian2').value = hasil;
                                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "2";

			}
			if(c == 1)
			{
			var hasil = c + 1;
				document.getElementById('antrian2').value = hasil;
                                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "2";

			}
			if(g == 1)
			{
			var hasil = g + 1;
				document.getElementById('antrian2').value = hasil;
                                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "2";

			}
			
		}
		
		if(e < c & e < g & g > c)
		{
			var hasil = g + 1;
			document.getElementById('antrian2').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "2";

		}
		
		if(e < c & e < g & c > g)
		{
			var hasil = c + 1;
			document.getElementById('antrian2').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "2";

		}
		
		if(e < c & e > g)
		{
			var hasil = c + 1;
			document.getElementById('antrian2').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "2";

		}
		
		if(e > c & c < g)
		{
			var hasil = g + 1;
			document.getElementById('antrian2').value = hasil;
            document.getElementById('teleer'). innerHTML = "2";
                            document.getElementById('antrianm').value = hasil;

		}
		
		if(e > c & e > g)
		{
			var hasil = e + 1;
			document.getElementById('antrian2').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "2";

		}
		
	}
	
	function angka3()
	{
		var b = document.getElementById('antrian1').value
		var c = parseInt(b);
		var d = document.getElementById('antrian2').value
		var e = parseInt(d);
		var f = document.getElementById('antrian3').value
		var g = parseInt(f);
		
		if(g == 0)
		{
			if(g == 0)
			{
				var hasil = g + 1;
				document.getElementById('antrian3').value = hasil;
                                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "3";

			}
			if(c == 1)
			{
				var hasil = c + 1;
				document.getElementById('antrian3').value = hasil;
                                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "3";

			}
			if(e == 1)
			{
				var hasil = e + 1;
				document.getElementById('antrian3').value = hasil;
                                document.getElementById('antrianm').value = hasil;
                document.getElementById('teleer'). innerHTML = "3";

			}
			
		}
		if(g < c & g < e & c > e)
		{
			var hasil = c + 1;
			document.getElementById('antrian3').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "3";

		}
		if(g < c & g < e & e > c)
		{
			var hasil = e + 1;
			document.getElementById('antrian3').value = hasil;
            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "3";

		}
		if(g < c & g > e)
		{
			var hasil = c + 1;
			document.getElementById('antrian3').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "3";

		}
		
		if(g > c & g < e)
		{
			var hasil = e + 1;
			document.getElementById('antrian3').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "3";

		}
		if(g > c & g > e)
		{
			var hasil = g + 1;
			document.getElementById('antrian3').value = hasil;
                            document.getElementById('antrianm').value = hasil;
            document.getElementById('teleer'). innerHTML = "3";

		}
		
	}